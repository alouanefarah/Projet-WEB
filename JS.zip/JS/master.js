//setting box landing page
//toggle spin class on icon
document.querySelector(".toggle-settings .fa-bars").onclick = function () {
    // toggle class fa spin for rotaton  
    this.classList.toggle('fa-spin');
    //toggle class open on main settings box 
    document.querySelector(".settings-box").classList.toggle("open");
};
document.querySelector(".settings-box .option-box .categories-list").onclick = function () {
    document.querySelector(".settings-box").classList.toggle("open");
};


//landing page
// Sélectionner l'élément de la page de destination
let landingPage = document.querySelector(".landing-page");

// Créer un tableau d'images
let IMAGESArray = ["04.jpg", "02.jpg", "03.jpg", "01.jpg","05.jpg"];

setInterval(() => {
    // Obtenir un nombre aléatoire
    let randomNumber = Math.floor(Math.random() * IMAGESArray.length);

    // Changer l'URL de l'image de fond
    landingPage.style.backgroundImage = 'url("IMAGES/' + IMAGESArray[randomNumber] + '")';
}, 10000);


