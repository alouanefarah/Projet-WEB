let preveiwContainer = document.querySelector('.products-preview');
let previewBox = preveiwContainer.querySelectorAll('.preview');

console.log(preveiwContainer);

document.querySelectorAll('.products-container .product').forEach(product =>{
    product.onclick = () =>{
    preveiwContainer.style.display = 'flex';
    let name = product.getAttribute('data-name');
    previewBox.forEach(preview =>{
    let target = preview.getAttribute('data-target');
    console.log(target);
    if(name == target){
        preview.classList.add('active');
    }
    });
};
});
previewBox.forEach(close =>{
    close.querySelector('.fa-times').onclick = () =>{
        close.classList.remove('active');
        preveiwContainer.style.display = 'none';

    };
});
let menu = document.querySelector('#bars');
let navbar = document.querySelector('.navbar');


menu.onclick = () => {
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');
} 
 window.onscroll = () => {
    menu.classList.remove('fa-times');
    navbar.classList.remove('active');
}  
let searchForm = document.querySelector('.search-form');
document.querySelector('#search-icon').onclick = () => {
    searchForm.classList.toggle('active');
}  
let loginForm = document.querySelector('.login-form');
document.querySelector('#login-btn').onclick = () => {
    loginForm.classList.toggle('active');
}