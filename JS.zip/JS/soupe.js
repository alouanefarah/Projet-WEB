let previewContainer = document.querySelector('.box-cont');
let previewBoxes = document.querySelectorAll('.box');


previewBoxes.forEach(box => {
    box.addEventListener('click', () => {
        let name = box.getAttribute('data-name');
        previewContainer.style.display = 'flex';
        document.querySelectorAll('.box').forEach(previewBox => {
            // Vérifier si le nom correspond au nom cible
            if (previewBox.getAttribute('data-target') === name) {
                previewBox.classList.add('active');
            } else {
                previewBox.classList.remove('active');
            }
        });
    });
});
previewBoxes.forEach(previewBox => {
    previewBox.querySelector('.fa-times').onclick = () => {
        previewBox.classList.remove('active');
        previewContainer.style.display = 'none';
    };
});